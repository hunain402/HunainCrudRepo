package org.carrental.UI;

public class main2 {
    public static void main(String[] args) {


        LoginUI loginUI = new LoginUI();
    }
}
